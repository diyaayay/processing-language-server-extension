This is [Source Sans](https://github.com/adobe-fonts/source-sans) from Adobe, but renamed to
prevent conflicts on Windows with other versions of Source Sans. See [issue 4747](https://github.com/processing/processing/issues/4747) in the old Processing repository for details. 

The license for this font can be found [here](https://github.com/adobe-fonts/source-sans/blob/release/LICENSE.md).

We're using [version 3.046 from 14 July 2021](https://github.com/adobe-fonts/source-sans/releases/tag/3.046R). 

After downloading the TTF, it was opened with [FontForge](https://fontforge.org/). The font and family names were changed using Element → Font Info, followed by File → Generate to create the new `.ttf` files.
